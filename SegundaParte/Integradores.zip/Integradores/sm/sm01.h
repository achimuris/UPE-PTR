#define SHARED_MEMORY_UPE "/MI_MEMORIA_SM"

#define DEF_AMARILLO '0'
#define DEF_ROJO '1'
#define DEF_VERDE '2'
#define DEF_AZUL '3'